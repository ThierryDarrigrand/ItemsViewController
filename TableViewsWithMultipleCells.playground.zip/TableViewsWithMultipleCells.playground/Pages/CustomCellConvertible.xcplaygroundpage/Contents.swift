//: [Previous](@previous)

import UIKit


struct Artist {
    var name: String
}


final class ArtistCell: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .value1, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension Artist: CustomCellConvertible {
    var cellDescriptor: CellDescriptor {
        return CellDescriptor(reuseIdentifier: "artist") {
            (cell : ArtistCell) in
            cell.textLabel?.text = self.name
        }
    }
}

struct Album {
    var title: String
}

final class AlbumCell: UITableViewCell {
    override init(style: UITableViewCellStyle, reuseIdentifier: String?) {
        super.init(style: .value2, reuseIdentifier: reuseIdentifier)
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}

extension Album : CustomCellConvertible {
    var cellDescriptor: CellDescriptor {
        return CellDescriptor(reuseIdentifier: "album") { (cell: AlbumCell) in
            cell.textLabel?.text = self.title
        }
    }
}

extension Album: CustomStringConvertible {
    var description: String {
        return title
    }
}

enum RecentItem {
    case album(Album)
    case artist(Artist)
}


extension RecentItem : CustomCellConvertible {
    var cellDescriptor: CellDescriptor {
        switch self {
        case let .artist(artist): return artist.cellDescriptor
        case let .album(album): return album.cellDescriptor
        }
    }
}

let artists: [Artist] = [
    Artist(name: "Prince"),
    Artist(name: "Glen Hansard"),
    Artist(name: "I Am Oak")
]

let albums: [Album] = [
    Album(title: "Blue Lines"),
    Album(title: "Oasem"),
    Album(title: "Bon Iver")
]

let recentItems: [RecentItem] = [
    .artist(artists[0]),
    .artist(artists[1]),
    .album(albums[1])
]

let recentItemsVC = ItemsViewController(items: recentItems) 

recentItemsVC.title = "Recents"

let nc = UINavigationController(rootViewController: recentItemsVC)

import PlaygroundSupport
PlaygroundPage.current.liveView = nc
